local M = {}

-- 尝试开火射击时调用
function M.shoot(api)
    if (api:getAimingProgress() >= 1) then
        api:shootOnce(api:isShootingNeedConsumeAmmo())
    end
end

return M