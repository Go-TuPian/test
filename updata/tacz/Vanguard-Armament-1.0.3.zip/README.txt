本拓展包需要 Arcana 1.2.9 或更高版本才可正常工作。
本拓展包使用了大量实验性内容，可能存在尚未发现的 BUG。
为新增改装配件槽位，本拓展包覆盖了部分官方包枪械数据。如需修改相关枪械数据，请基于本拓展包内的数据进行修改。

This add-on pack requires Arcana 1.2.9 or later to function properly.
This add-on pack uses a large amount of experimental content, so undiscovered bugs may still exist.
In order to add new modification attachment slots, this add-on pack overwrites part of the firearm data from the official pack. If you need to modify the related firearm data, please base your changes on the data included in this add-on pack.

Ce pack d’extension nécessite Arcana 1.2.9 ou une version ultérieure pour fonctionner correctement.
Ce pack d’extension utilise de nombreux contenus expérimentaux ; des bugs non encore découverts peuvent donc subsister.
Afin d’ajouter de nouveaux emplacements pour les accessoires de modification, ce pack d’extension remplace une partie des données d’armes du pack officiel. Si vous devez modifier les données d’armes concernées, veuillez vous baser sur les données incluses dans ce pack d’extension.

Este paquete de expansión requiere Arcana 1.2.9 o una versión posterior para funcionar correctamente.
Este paquete de expansión utiliza una gran cantidad de contenido experimental, por lo que aún pueden existir errores no descubiertos.
Para añadir nuevas ranuras de accesorios de modificación, este paquete de expansión sobrescribe parte de los datos de armas del paquete oficial. Si necesitas modificar los datos de armas relacionados, realiza los cambios tomando como base los datos incluidos en este paquete de expansión.

Для корректной работы этого дополнительного пакета требуется Arcana версии 1.2.9 или выше.
В этом дополнительном пакете используется большое количество экспериментального контента, поэтому в нём могут присутствовать ещё не обнаруженные ошибки.
Чтобы добавить новые слоты для модификаций и навесного оборудования, этот дополнительный пакет перезаписывает часть данных огнестрельного оружия из официального пакета. Если вам необходимо изменить соответствующие данные оружия, используйте данные из этого дополнительного пакета в качестве основы.

تتطلب حزمة الإضافة هذه إصدار Arcana 1.2.9 أو أحدث لكي تعمل بشكل صحيح.
تستخدم حزمة الإضافة هذه قدرًا كبيرًا من المحتوى التجريبي، لذلك قد تحتوي على أخطاء غير مكتشفة بعد.
من أجل إضافة خانات جديدة لملحقات التعديل، تقوم حزمة الإضافة هذه بالكتابة فوق جزء من بيانات الأسلحة النارية الموجودة في الحزمة الرسمية. إذا كنت بحاجة إلى تعديل بيانات الأسلحة ذات الصلة، فيُرجى الاعتماد على البيانات الموجودة داخل حزمة الإضافة هذه كأساس للتعديل.

本拡張パックが正常に動作するには、Arcana 1.2.9 以降が必要です。
本拡張パックには多くの実験的な内容が含まれているため、まだ発見されていない不具合が存在する可能性があります。
改造用アタッチメントスロットを追加するため、本拡張パックは一部の公式パックの銃器データを上書きしています。該当する銃器データを変更する場合は、本拡張パック内のデータを基に編集してください。

이 확장팩이 정상적으로 작동하려면 Arcana 1.2.9 이상 버전이 필요합니다.
이 확장팩에는 많은 실험적 콘텐츠가 사용되어 있으며, 아직 발견되지 않은 버그가 존재할 수 있습니다.
개조 부착물 슬롯을 추가하기 위해 이 확장팩은 공식 팩의 일부 총기 데이터를 덮어씁니다. 관련 총기 데이터를 수정해야 하는 경우, 이 확장팩에 포함된 데이터를 기준으로 수정해 주세요.
