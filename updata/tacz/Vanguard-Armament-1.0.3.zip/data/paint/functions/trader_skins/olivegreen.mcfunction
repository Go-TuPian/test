execute if predicate paint:trader_skins/reward_chance run give @s tacz:attachment{AttachmentId:"paint:skin_olivegreen"} 1
advancement revoke @s only paint:trader_skins/olivegreen
