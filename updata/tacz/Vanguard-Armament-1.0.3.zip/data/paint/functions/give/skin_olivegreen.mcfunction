give @s tacz:attachment{AttachmentId:"paint:skin_olivegreen"} 1
