give @s tacz:attachment{AttachmentId:"paint:skin_winered"} 1
