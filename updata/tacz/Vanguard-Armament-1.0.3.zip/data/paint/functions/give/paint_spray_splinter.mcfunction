give @s tacz:attachment{AttachmentId:"paint:paint_spray_splinter"} 1
