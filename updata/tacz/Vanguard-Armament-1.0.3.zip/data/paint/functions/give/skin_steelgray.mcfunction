give @s tacz:attachment{AttachmentId:"paint:skin_steelgray"} 1
