give @s tacz:attachment{AttachmentId:"paint:paint_spray_custom_flow"} 1
