give @s tacz:attachment{AttachmentId:"paint:paint_spray_woodland"} 1
