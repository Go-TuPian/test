give @s tacz:attachment{AttachmentId:"paint:paint_spray_aurora"} 1
