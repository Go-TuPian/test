give @s tacz:attachment{AttachmentId:"paint:paint_spray_digital"} 1
