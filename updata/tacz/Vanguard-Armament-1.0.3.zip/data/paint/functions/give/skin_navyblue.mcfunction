give @s tacz:attachment{AttachmentId:"paint:skin_navyblue"} 1
