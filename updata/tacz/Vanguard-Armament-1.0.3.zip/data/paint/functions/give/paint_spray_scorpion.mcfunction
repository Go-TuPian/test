give @s tacz:attachment{AttachmentId:"paint:paint_spray_scorpion"} 1
