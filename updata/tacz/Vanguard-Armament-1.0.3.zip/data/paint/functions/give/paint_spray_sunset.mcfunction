give @s tacz:attachment{AttachmentId:"paint:paint_spray_sunset"} 1
