give @s tacz:attachment{AttachmentId:"paint:skin_city_camo"} 1
