give @s tacz:attachment{AttachmentId:"paint:paint_spray_solid"} 1
