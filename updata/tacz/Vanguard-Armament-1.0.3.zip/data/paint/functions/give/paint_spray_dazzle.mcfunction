give @s tacz:attachment{AttachmentId:"paint:paint_spray_dazzle"} 1
