give @s tacz:attachment{AttachmentId:"paint:paint_spray_arctic"} 1
