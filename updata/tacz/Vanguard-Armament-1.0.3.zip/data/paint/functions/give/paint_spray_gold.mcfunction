give @s tacz:attachment{AttachmentId:"paint:paint_spray_gold"} 1
