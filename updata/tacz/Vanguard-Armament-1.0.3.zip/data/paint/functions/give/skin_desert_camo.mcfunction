give @s tacz:attachment{AttachmentId:"paint:skin_desert_camo"} 1
