give @s tacz:attachment{AttachmentId:"paint:paint_spray_tiger"} 1
