give @s tacz:attachment{AttachmentId:"paint:skin_standard"} 1
