give @s tacz:attachment{AttachmentId:"paint:paint_spray_solid_uniform"} 1
