give @s tacz:attachment{AttachmentId:"paint:skin_frozen_camo"} 1
