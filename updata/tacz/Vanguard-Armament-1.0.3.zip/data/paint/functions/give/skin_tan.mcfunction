give @s tacz:attachment{AttachmentId:"paint:skin_tan"} 1
