-- Injection is an Arcana transaction, never a fired bullet or reload.
local M = {}
function M.shoot(api) end
function M.start_reload(api) return false end
function M.start_bolt(api) return false end
return M
