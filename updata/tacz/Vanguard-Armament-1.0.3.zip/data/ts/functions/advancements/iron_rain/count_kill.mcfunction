execute unless score @s ts_adm_window matches 1.. run scoreboard players set @s ts_adm_kills 0
execute unless score @s ts_adm_window matches 1.. run scoreboard players set @s ts_adm_window 60
scoreboard players add @s ts_adm_kills 1
execute if score @s ts_adm_kills matches 10.. run advancement grant @s only ts:iron_rain
advancement revoke @s only ts:internal/adm_kill
