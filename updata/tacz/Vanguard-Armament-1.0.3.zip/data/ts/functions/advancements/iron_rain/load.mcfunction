scoreboard objectives add ts_adm_kills dummy
scoreboard objectives add ts_adm_window dummy
schedule function ts:advancements/iron_rain/loop 1t replace
