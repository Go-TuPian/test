execute as @a[scores={ts_adm_window=1..}] run function ts:advancements/iron_rain/window_tick
schedule function ts:advancements/iron_rain/loop 1t replace
