scoreboard players remove @s ts_adm_window 1
execute if score @s ts_adm_window matches 0 run scoreboard players set @s ts_adm_kills 0
