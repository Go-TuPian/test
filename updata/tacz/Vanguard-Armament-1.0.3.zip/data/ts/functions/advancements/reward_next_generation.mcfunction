give @s tacz:modern_kinetic_gun{GunId:"ts:railgun"} 1
give @s tacz:modern_kinetic_gun{GunId:"ts:py132a"} 1
