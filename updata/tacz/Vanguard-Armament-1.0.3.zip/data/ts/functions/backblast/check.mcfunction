tag @s remove ts_vanguard_backblast_blocked
execute positioned ^ ^ ^-0.25 unless block ~ ~ ~ #minecraft:replaceable run tag @s add ts_vanguard_backblast_blocked
execute positioned ^ ^ ^-0.50 unless block ~ ~ ~ #minecraft:replaceable run tag @s add ts_vanguard_backblast_blocked
execute positioned ^ ^ ^-0.75 unless block ~ ~ ~ #minecraft:replaceable run tag @s add ts_vanguard_backblast_blocked
execute positioned ^ ^ ^-1.00 unless block ~ ~ ~ #minecraft:replaceable run tag @s add ts_vanguard_backblast_blocked
execute positioned ^ ^ ^-1.25 unless block ~ ~ ~ #minecraft:replaceable run tag @s add ts_vanguard_backblast_blocked
execute positioned ^ ^ ^-1.50 unless block ~ ~ ~ #minecraft:replaceable run tag @s add ts_vanguard_backblast_blocked
execute positioned ^ ^ ^-1.75 unless block ~ ~ ~ #minecraft:replaceable run tag @s add ts_vanguard_backblast_blocked
execute positioned ^ ^ ^-2.00 unless block ~ ~ ~ #minecraft:replaceable run tag @s add ts_vanguard_backblast_blocked
execute if entity @s[tag=ts_vanguard_backblast_blocked] run damage @s 40 ts:backblast
tag @s remove ts_vanguard_backblast_blocked
