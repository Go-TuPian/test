clear @s tacz:ammo{AmmoId:"ts:bandage"} 1
effect give @s minecraft:regeneration 3 1 true
playsound minecraft:item.honey_bottle.drink player @s ~ ~ ~ 0.5 1.2
particle minecraft:heart ~ ~1 ~ 0.3 0.4 0.3 0.05 3 force @s
