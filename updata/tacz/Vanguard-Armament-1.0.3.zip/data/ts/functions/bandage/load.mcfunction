scoreboard objectives add ts_bandage_hold dummy
scoreboard objectives add ts_bandage_hp dummy
scoreboard objectives add ts_bandage_max dummy
schedule function ts:bandage/loop 1t replace
