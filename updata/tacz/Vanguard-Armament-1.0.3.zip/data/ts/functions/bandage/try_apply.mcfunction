scoreboard players set @s ts_bandage_hold -1
execute store result score @s ts_bandage_hp run data get entity @s Health 10
execute store result score @s ts_bandage_max run attribute @s minecraft:generic.max_health get 10
execute if score @s ts_bandage_hp < @s ts_bandage_max run function ts:bandage/apply
