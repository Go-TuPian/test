function ts:bandage/tick
schedule function ts:bandage/loop 2t replace
