scoreboard players add @s ts_bandage_hold 0
execute if score @s ts_bandage_hold matches 0..19 run scoreboard players add @s ts_bandage_hold 2
execute if score @s ts_bandage_hold matches 20.. run function ts:bandage/try_apply
