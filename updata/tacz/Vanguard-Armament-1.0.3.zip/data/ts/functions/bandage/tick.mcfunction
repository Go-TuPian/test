execute as @a[scores={ts_bandage_hold=1..}] unless predicate ts:bandage/using run scoreboard players set @s ts_bandage_hold 0
execute as @a[scores={ts_bandage_hold=..-1}] unless predicate ts:bandage/using run scoreboard players set @s ts_bandage_hold 0
execute as @a at @s if predicate ts:bandage/using run function ts:bandage/hold
