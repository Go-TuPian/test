forceload remove ~ ~
scoreboard players reset @s ts_gvs_ttl
kill @s
