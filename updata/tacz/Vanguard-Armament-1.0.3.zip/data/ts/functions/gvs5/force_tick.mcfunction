execute as @e[type=minecraft:marker,tag=ts.gvs_force] at @s run function ts:gvs5/force_expire
