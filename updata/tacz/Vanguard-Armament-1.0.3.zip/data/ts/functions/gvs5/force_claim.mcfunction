# Already-owned chunks share the latest strike's expiry; pre-existing external
# forceloads are never registered or released by this pack.
execute if entity @e[type=minecraft:marker,tag=ts.gvs_force,distance=..0.1] run scoreboard players set @e[type=minecraft:marker,tag=ts.gvs_force,distance=..0.1] ts_gvs_ttl 350
execute store success score #loaded ts_gvs_ttl run forceload query ~ ~
execute if score #loaded ts_gvs_ttl matches 0 run function ts:gvs5/force_new
