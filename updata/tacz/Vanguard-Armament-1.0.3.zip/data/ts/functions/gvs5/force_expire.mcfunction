scoreboard players remove @s ts_gvs_ttl 1
execute if score @s ts_gvs_ttl matches ..0 run function ts:gvs5/force_release
