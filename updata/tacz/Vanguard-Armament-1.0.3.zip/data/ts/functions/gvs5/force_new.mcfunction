execute store success score #added ts_gvs_ttl run forceload add ~ ~
execute if score #added ts_gvs_ttl matches 1 run summon minecraft:marker ~ ~ ~ {Tags:["ts.gvs_force"]}
execute if score #added ts_gvs_ttl matches 1 run scoreboard players set @e[type=minecraft:marker,tag=ts.gvs_force,distance=..0.1] ts_gvs_ttl 350
