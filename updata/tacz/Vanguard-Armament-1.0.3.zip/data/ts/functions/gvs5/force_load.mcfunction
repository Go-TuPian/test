scoreboard objectives add ts_gvs_ttl dummy
