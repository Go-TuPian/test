-- Read-only visual forecast. Missing tick_reload/shoot hooks deliberately retain TacZ defaults.
local M = {}
local function incomingCount(api)
    local current, capacity = api:getAmmoAmount(), api:getMaxAmmoCount()
    local needed = math.max(0, api:getNeededAmmoAmount())
    if not api:isReloadingNeedConsumeAmmo() then return capacity end
    local gun, stack = api:getAbstractGunItem(), api:getItemStack()
    if gun:useDummyAmmo(stack) then
        return math.min(capacity, current + math.min(needed, gun:getDummyAmmoAmount(stack)))
    end
    local shooter = api:getShooter()
    -- Pinned Forge 1.20.1 SRG methods, same inventory walk as TacZ GunHudOverlay.
    -- No extractItem, consumeAmmoFromPlayer or inventory write occurs here.
    if not shooter.m_150109_ then return current end
    local inventory = shooter:m_150109_()
    local available = 0
    for slot = 0, inventory:m_6643_() - 1 do
        local itemStack = inventory:m_8020_(slot)
        local item = itemStack:m_41720_()
        if item.isAmmoOfGun and item:isAmmoOfGun(stack, itemStack) then
            available = available + itemStack:m_41613_()
        elseif item.isAmmoBoxOfGun and item:isAmmoBoxOfGun(stack, itemStack) then
            if item:isAllTypeCreative(itemStack) or item:isCreative(itemStack) then return capacity end
            available = available + item:getAmmoCount(itemStack)
        end
        if available >= needed then return capacity end
    end
    return math.min(capacity, current + available)
end
function M.start_reload(api)
    local nbt = api:getNbt()
    local ok, count = pcall(incomingCount, api)
    nbt:putInt("AK50ReloadPreview", ok and count or -1)
    nbt:putInt("AK50ReloadOldAmmo", api:getAmmoAmount())
    nbt:putInt("AK50ReloadSerial", nbt:getInt("AK50ReloadSerial") + 1)
    if not ok then print("AK50 reload preview unavailable: " .. tostring(count)) end
    return true
end
return M
