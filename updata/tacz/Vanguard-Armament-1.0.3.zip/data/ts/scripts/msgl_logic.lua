-- Fixed physical cylinder: positive code=live, negative code=spent, zero=empty.
-- Selection/refund/rendering remain existing Arcana components.
local M = {}
local ids={'tacz:40mm','ts:40mm_m433','ts:40mm_m1060','ts:40mm_m576','ts:40mm_m651',
    'ts:40mm_m680','ts:40mm_mv_he','ts:40mm_mv_m430','ts:40mm_mv_proximity'}
local codes={}; for i,id in ipairs(ids) do codes[id]=i end
local function cylinder(api) return api:getNbt():getCompound('MSGLCylinder') end
local function changed(s) s:putInt('RenderDirty',1) end
-- Resolve the mapped array reader once. LuaJ JavaArray indexes are one-based.
-- In newer TacZ, nbt() returns a copy, so array changes must be written back.
local array_method
local function slots(s)
    local raw=s:nbt()
    if not array_method then
        if pcall(function() return raw:getIntArray('AmmoCodes') end) then array_method='getIntArray'
        else array_method='m_128465_' end
    end
    return raw[array_method](raw,'AmmoCodes')
end
local function save_slots(api,s,rounds)
    local raw=s:nbt()
    local target=raw[array_method](raw,'AmmoCodes')
    for i=1,6 do target[i]=rounds[i] end
    api:getNbt():putCompound('MSGLCylinder',s:from(raw))
end
local function selected(api,s)
    local extras=api:getNbt():getCompound('Extras')
    local id=extras and extras:getString('ExtraAmmo') or ''
    if id=='' then id=s:getInt('ModuleMV')==1 and ids[7] or ids[1] end
    return codes[id] or 0
end
local function allowed(code,s)
    return code>=1 and code<=9 and (s:getInt('ModuleMV')==1 and code>=7 or s:getInt('ModuleMV')==0 and code<=6)
end
local function compatible(s,rounds,code)
    if not allowed(code,s) then return false end
    for i=1,6 do if rounds[i]>0 and not allowed(rounds[i],s) then return false end end
    return true
end
local function author_time(api,c) return api:getReloadTime()/c.modifier end
local function cycle(s,c)
    c.origin=s:getInt('Index')
    c.target=c.empty and (c.empty_origin+c.step-1)%6 or (c.origin+5)%6
    c.rotated=false; c.ejected=false; c.presented=false
    s:putInt('ReloadOrigin',c.origin); s:putInt('FeedCode',0)
    s:putInt('Rollback',0)
    s:putInt('HandSlot',0); s:putInt('HiddenSlot',-1); s:putInt('ReloadPhase',0)
    changed(s)
end
local function timing(api,c)
    local p=api:getScriptParams()
    if c.empty then return p.intro_empty*1000,(c.step==1 and p.loop_empty_first or p.loop_empty)*1000,p.feed_empty*1000,p.end_empty*1000 end
    return p.intro_tactical*1000,p.loop_tactical*1000,p.feed_tactical*1000,p.end_tactical*1000
end
local function finish(api,c,at)
    local s=cylinder(api)
    if c.finish_at==nil then
        c.finish_at=at
        s:putInt('Rollback',not c.empty and c.rotated and not c.fed and 1 or 0)
        s:putInt('HandSlot',0); s:putInt('HiddenSlot',-1); changed(s)
    end
    local _,_,_,ending=timing(api,c)
    local remaining=ending-(author_time(api,c)-c.finish_at)
    api:cacheScriptData(c)
    if remaining<=0 then
        if not c.empty and c.rotated and not c.fed then s:putInt('Index',c.origin) end
        s:putInt('ReloadActive',0); s:putInt('Busy',0); s:putInt('Rollback',0)
        s:putInt('ShotState',-1); changed(s) -- refresh next live ID after mixed reload/cancel.
        return NOT_RELOADING,-1
    end
    return c.empty and EMPTY_RELOAD_FINISHING or TACTICAL_RELOAD_FINISHING,remaining*c.modifier
end
function M.start_reload(api)
    local s=cylinder(api)
    if not s or s:getInt('Version')~=4 or not compatible(s,slots(s),s:getInt('PendingCode')) then return false end
    if api:getNeededAmmoAmount()<=0 or not api:hasAmmoToConsume() then return false end
    local modifier=api:getReloadTimeModifier()
    if modifier<=0 or modifier~=modifier then modifier=1 end
    local c={empty=api:getAmmoAmount()==0,step=1,fed=false,loaded=0,needed=api:getNeededAmmoAmount(),modifier=modifier,empty_origin=s:getInt('Index')}
    c.loop_at=timing(api,c)
    s:putInt('ReloadActive',1); s:putInt('ShotState',0)
    cycle(s,c); api:cacheScriptData(c); return true
end
function M.tick_reload(api)
    local c=api:getCachedScriptData()
    if not c then return NOT_RELOADING,-1 end
    local s=cylinder(api)
    if not s or s:getInt('ReloadActive')~=1 then return NOT_RELOADING,-1 end
    if c.finish_at then return finish(api,c,c.finish_at) end
    local rounds=slots(s)
    local now=author_time(api,c)
    if c.empty and not c.intro_ejected and now>=850 then
        for i=1,6 do rounds[i]=0 end
        save_slots(api,s,rounds)
        c.intro_ejected=true; changed(s)
    end
    for _=1,7 do
        local _,duration,feed=timing(api,c)
        if now<c.loop_at then break end
        local progress=now-c.loop_at
        if c.empty and not c.presented then
            s:putInt('HandSlot',c.step); s:putInt('HiddenSlot',c.target); s:putInt('ReloadPhase',2)
            c.presented=true; changed(s)
        elseif not c.empty and not c.rotated and progress>=483.3 then
            s:putInt('Index',c.target); s:putInt('HandSlot',1)
            s:putInt('HiddenSlot',c.target); s:putInt('ReloadPhase',1)
            c.rotated=true; changed(s)
        end
        if not c.empty and not c.ejected and progress>=1383.3 then
            if rounds[c.target+1]>0 then return finish(api,c,now) end
            rounds[c.target+1]=0; save_slots(api,s,rounds); s:putInt('ReloadPhase',2)
            c.ejected=true; changed(s)
        end
        if not c.fed and now>=c.loop_at+feed then
            if c.loaded>=c.needed or api:getNeededAmmoAmount()<=0 or rounds[c.target+1]>0 then return finish(api,c,now) end
            local code=selected(api,s)
            if code~=s:getInt('PendingCode') or not compatible(s,rounds,code) then return finish(api,c,now) end
            local consumed=1
            if api:isReloadingNeedConsumeAmmo() then consumed=api:consumeAmmoFromPlayer(1) end
            if consumed~=1 then return finish(api,c,now) end
            api:putAmmoInMagazine(consumed)
            rounds[c.target+1]=code; save_slots(api,s,rounds); s:putInt('FeedCode',code)
            -- Reveal the real committed round before the local animation can
            -- hide its hand copy at the next clip boundary. Keep that hand's
            -- FeedCode/visibility until normal cycle cleanup; no extra packets.
            s:putInt('HiddenSlot',-1)
            s:putInt('LastCount',api:getAmmoAmount()); s:putInt('LastNativeCode',code); changed(s)
            c.loaded=c.loaded+consumed; c.fed=true
        end
        if now<c.loop_at+duration then break end
        local boundary=c.loop_at+duration
        if c.loaded>=c.needed or not api:hasAmmoToConsume() then return finish(api,c,boundary) end
        c.step=c.step+1; c.fed=false; c.loop_at=boundary; cycle(s,c)
    end
    api:cacheScriptData(c)
    local _,duration,_,ending=timing(api,c)
    local remaining=math.max(1,c.loop_at+duration-now)+(c.needed-c.loaded)*duration+ending
    return c.empty and EMPTY_RELOAD_FEEDING or TACTICAL_RELOAD_FEEDING,remaining*c.modifier
end
function M.interrupt_reload(api)
    local c=api:getCachedScriptData()
    if c and not c.finish_at then finish(api,c,author_time(api,c)) end
end
function M.shoot(api)
    local s=cylinder(api)
    if not s or s:getInt('Version')~=4 or not allowed(slots(s)[s:getInt('Index')+1],s) then return end
    local consume=api:isShootingNeedConsumeAmmo()
    s:putInt('Busy',1); s:putInt('ShotState',consume and 1 or 2)
    api:shootOnce(consume)
    -- addCycleTask executes the first cycle synchronously in pinned TacZ0929.
    -- Spawn callback flips the handshake negative; retain that until the HUD
    -- component runs, but close a cancelled/no-spawn shot without a fake commit.
    if s:getInt('ShotState')>0 then s:putInt('ShotState',0) end
    s:putInt('Busy',0) -- also closes a rejected/dry shot with no spawn callback.
end
return M
