-- The item is a shield, never a gun. Native melee remains available on the melee key.
local M = {}
function M.shoot(api) end
function M.start_reload(api) return false end
function M.start_bolt(api) return false end
return M
