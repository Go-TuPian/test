-- Shared injector presentation. Arcana owns its extra injection track.
-- Native shoot/reload/ADS signals must not play rifle motions or eject shells.
local M = {}
local base, idle, stowed = {}, {}, {}
local function play(context, name, track, mode, fade)
    context:runAnimation(name, context:getTrack(0, track), false, mode, fade)
end
function base.entry(this, context)
    play(context, "static_idle", 0, LOOP, 0)
end
function idle.transition(this, context, input)
    if input == INPUT_DRAW then
        play(context, "draw", 1, PLAY_ONCE_STOP, 0)
    elseif input == INPUT_PUT_AWAY then
        play(context, "put_away_spec", 1, PLAY_ONCE_HOLD, 0.08)
        return stowed
    end
end
function M:initialize(context)
    context:ensureTrackLineSize(1)
    context:ensureTracksAmount(0, 2)
    context:stopAnimation(context:getTrack(0, 0))
    context:stopAnimation(context:getTrack(0, 1))
    context:setShouldHideCrossHair(true)
end
function M:exit(context)
    context:setShouldHideCrossHair(false)
end
function M:states() return {base, idle} end
return M
