-- Original LWM animation clips; native skinned hands replace editor proxies.
local M = {}
local BASE, ROUND, ACTION, MOTION, RECOIL = 0, 1, 2, 3, 4
local RETURN_FADE, RETURN_SETTLE_MS = 0.18, 220
local base, idle, busy, returning, stowed, motion, round = {}, {}, {}, {}, {}, {}, {}
local function track(c, i) return c:getTrack(0, i) end
local function play(c, name, i, blend, mode, fade)
    c:runAnimation(name, track(c, i), blend, mode, fade)
end
local function action(this, c, input)
    if input == INPUT_PUT_AWAY then
        this.stowing = true
        this.actionActive = true
        play(c, "put_away", ACTION, false, PLAY_ONCE_HOLD, 0.12)
        return stowed
    elseif input == INPUT_DRAW then
        this.stowing = false
        this.actionActive = true
        play(c, "draw", ACTION, false, PLAY_ONCE_HOLD, 0)
        return busy
    elseif input == INPUT_RELOAD then
        this.actionActive = true
        this.reloading = true
        play(c, "reload", ACTION, false, PLAY_ONCE_HOLD, 0.12)
        return busy
    elseif input == INPUT_INSPECT then
        this.actionActive = true
        play(c, "inspect", ACTION, false, PLAY_ONCE_HOLD, 0.15)
        return busy
    elseif input == INPUT_SHOOT then
        -- Recoil must not change an absolute pose track to additive blending
        -- while that track is still handing its pose back to native ADS.
        play(c, "shoot", RECOIL, true, PLAY_ONCE_STOP, 0.04)
    end
end
function base.entry(this,c)
    -- The author's low-ready root is pose0; pose1 is the original raised root.
    -- Sample native ADS progress, including reversals, rather than starting
    -- separate timed clips that can desynchronise on a quick aim cancellation.
    play(c,"static_idle",BASE,false,PLAY_ONCE_HOLD,0)
    c:pauseAnimation(track(c,BASE))
end
function base.update(this,c)
    c:setAnimationProgress(track(c,BASE),c:getAimingProgress(),true)
end
function idle.transition(this,c,input) return action(this,c,input) end
function busy.update(this,c)
    if c:isHolding(track(c,ACTION)) or c:isStopped(track(c,ACTION)) then
        c:trigger("enforcer:pose_return")
    end
end
function busy.transition(this,c,input)
    if input == "enforcer:pose_return" then return returning end
    return action(this,c,input)
end
function returning.entry(this,c)
    -- Keep the completed authored pose visible until native track blending
    -- can hand it over. The target samples CURRENT ADS, not entry-time ADS.
    this.reloading=false
    this.returnUntil=c:getCurrentTimestamp()+RETURN_SETTLE_MS
    play(c,"action_return",ACTION,false,LOOP,RETURN_FADE)
    c:setAnimationProgress(track(c,ACTION),c:getAimingProgress(),false)
end
function returning.update(this,c)
    -- Seconds 0..1 encode the same pose as BASE. The bridge extends to 2s
    -- so it cannot wrap/hold when ADS reaches 1, and needs no pause/restart.
    c:setAnimationProgress(track(c,ACTION),c:getAimingProgress(),false)
    if c:getCurrentTimestamp() >= this.returnUntil then
        c:stopAnimation(track(c,ACTION))
        this.actionActive=false
        c:trigger("enforcer:pose_ready")
    end
end
function returning.transition(this,c,input)
    if input == "enforcer:pose_ready" then return idle end
    -- A new native-authorised action can replace the bridge using normal
    -- track blending. This path never edits ammo or interrupts reload logic.
    return action(this,c,input)
end
function motion.entry(this,c)
    this.motionInput=INPUT_IDLE
    this.motion="locomotion_idle"
    play(c,this.motion,MOTION,true,LOOP,0)
end
function motion.transition(this,c,input)
    if input == INPUT_RUN or input == INPUT_WALK or input == INPUT_IDLE then
        this.motionInput=input
    end
end
function motion.update(this,c)
    -- One owner for locomotion: action/ADS never fight a stale sprint pose.
    -- Keep ALL root channels in each motion clip. Native interrupted fades
    -- preserve matched channels, but can drop a missing channel's recovery.
    local name="locomotion_idle"
    if not this.stowing and not this.actionActive and
       not c:isAiming() and c:getAimingProgress() <= 0.001 then
        if this.motionInput == INPUT_RUN then name="run"
        elseif this.motionInput == INPUT_WALK then name="walk_forward" end
    end
    if name ~= this.motion then
        local fade=this.motion=="run" and 0.28 or 0.24
        this.motion=name
        play(c,name,MOTION,true,LOOP,fade)
    end
end
function round.update(this,c)
    -- A reload clip owns missile position and visibility until its animation
    -- ends; reserve-round visibility must not override its insertion frames.
    local value=(c:getAmmoCount()>0 or c:hasBulletInBarrel()) and 1 or 0
    if this.reloading then value=1 end
    if value ~= this.roundVisible then
        this.roundVisible=value
        play(c,value==1 and "round_visible" or "round_hidden",ROUND,false,LOOP,0)
    end
end
function M:initialize(c)
    c:ensureTrackLineSize(1) c:ensureTracksAmount(0,5)
    for i=0,4 do c:stopAnimation(track(c,i)) end
    self.stowing=false self.reloading=false self.roundVisible=nil self.actionActive=false
    self.returnUntil=0
    c:setShouldHideCrossHair(true)
end
function M:exit(c) c:setShouldHideCrossHair(false) end
function M:states() return {base,idle,motion,round} end
return M
