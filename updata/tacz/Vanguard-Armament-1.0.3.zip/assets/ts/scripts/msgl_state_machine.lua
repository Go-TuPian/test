-- Component-first candidate: RenderUtil components own every visibility flag.
-- This script reads NBT and schedules existing animation APIs only. It does not
-- predict packet arrival or claim frame-atomic NBT/RenderUtil synchronization.
local base = require('tacz_default_state_machine')
local idle = setmetatable({}, {__index=base.main_track_states.idle})
local reload, rotor = {}, {}
local function main(c) return c:getTrack(base.STATIC_TRACK_LINE,base.MAIN_TRACK) end
local function indexTrack(c) return c:getTrack(base.STATIC_TRACK_LINE,base.PARALLEL_TRACK_1) end
local function returnTrack(c) return c:getTrack(base.STATIC_TRACK_LINE,base.PARALLEL_TRACK_2) end
local function state(c)
    local nbt=c:getNbtAccessor()
    return nbt and nbt:getCompound('MSGLCylinder')
end
local function value(nbt,key) return nbt and nbt:getInt(key) or 0 end
local function index(nbt) return value(nbt,'Index')%6 end
local function beginReturn(self,c,nbt)
    local r=self.msgl_reload
    if not r or not r.closing or r.return_started or value(nbt,'Rollback')~=1 then return end
    -- Original target orientation == origin orientation + 60 degrees. Move the
    -- cumulative parent to origin and let this native clip return 60 -> 0.
    self.msgl_restore_index=value(nbt,'ReloadOrigin')%6
    r.return_started=true
    c:runAnimation('reload_msgl_index_return',returnTrack(c),false,PLAY_ONCE_STOP,0)
end
local function close(self,c)
    local r=self.msgl_reload
    if not r or r.closing then return end
    r.closing=true
    c:runAnimation(r.empty and 'reload_empty_end' or 'reload_tactical_end',main(c),false,PLAY_ONCE_STOP,.1)
    beginReturn(self,c,state(c))
end
function idle.transition(self,c,input)
    if input==INPUT_RELOAD then return self.main_track_states.reload end
    if input==INPUT_SHOOT then return nil end -- no automatic case ejection
    return base.main_track_states.idle.transition(self,c,input)
end
function reload.entry(self,c)
    local nbt=state(c)
    self.msgl_reload={empty=c:getAmmoCount()==0,step=0,
        need=math.max(0,c:getMaxAmmoCount()-c:getAmmoCount()),closing=false,
        saw_active=value(nbt,'ReloadActive')==1,return_started=false}
    self.msgl_restore_index=nil
    local r=self.msgl_reload
    c:runAnimation(r.empty and 'reload_empty_into' or 'reload_tactical_into',main(c),false,PLAY_ONCE_HOLD,.1)
end
function reload.update(self,c)
    local r=self.msgl_reload
    if not r then return end
    local nbt=state(c)
    if value(nbt,'ReloadActive')==1 then r.saw_active=true end
    if r.closing then
        beginReturn(self,c,nbt)
        if c:isStopped(main(c)) then c:trigger('msgl_reload_done') end
        return
    end
    if value(nbt,'Rollback')==1 then close(self,c); return end
    if c:isHolding(main(c)) then
        -- PendingAmmo can differ from the currently selected ballistic cartridge.
        -- Do not call hasAmmoToConsume() for that different ID: server components
        -- and the existing feed path are authoritative for reserve exhaustion.
        if r.step>=r.need or c:getAmmoCount()>=c:getMaxAmmoCount()
            or (r.saw_active and value(nbt,'ReloadActive')~=1) then close(self,c); return end
        r.step=r.step+1
        c:runAnimation(r.empty and ('reload_empty_loop'..r.step) or 'reload_tactical_loop',main(c),false,PLAY_ONCE_HOLD,0)
    end
end
function reload.transition(self,c,input)
    if input=='msgl_reload_done' then self.msgl_reload=nil; return self.main_track_states.idle end
    if input==INPUT_CANCEL_RELOAD then close(self,c); return nil end
    if input==INPUT_PUT_AWAY then
        self.msgl_reload=nil; self.msgl_restore_index=nil
        return base.main_track_states.idle.transition(self,c,input)
    end
    return nil
end
function rotor.entry(self,c)
    c:runAnimation('static_msgl_physical_index',indexTrack(c),false,LOOP,0)
    c:pauseAnimation(indexTrack(c))
    rotor.update(self,c)
end
function rotor.update(self,c)
    local nbt=state(c)
    local h=index(nbt)
    if self.msgl_restore_index~=nil then
        if h==self.msgl_restore_index and value(nbt,'Rollback')~=1 then self.msgl_restore_index=nil
        else h=self.msgl_restore_index end
    end
    c:setAnimationProgress(indexTrack(c),h+.01,false)
end
local M=setmetatable({main_track_states=setmetatable({idle=idle,reload=reload},{__index=base.main_track_states})},{__index=base})
function M:initialize(c)
    base.initialize(self,c)
    self.msgl_reload=nil; self.msgl_restore_index=nil
end
function M:states()
    local s=base.states(self); s[#s+1]=rotor; return s
end
function M:exit(c)
    local controller=c:getStateMachine():getAnimationController()
    controller:removeAnimation(indexTrack(c)); controller:removeAnimation(returnTrack(c))
    self.msgl_reload=nil; self.msgl_restore_index=nil
end
return M
