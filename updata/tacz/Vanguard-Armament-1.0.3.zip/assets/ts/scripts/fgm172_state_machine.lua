-- Keep the FGM-172 movement override, while inheriting the disposable
-- launcher's local empty put-away selection.
local default = require("ts_singleuse_launcher_state_machine")

local BLENDING_TRACK_LINE = default.BLENDING_TRACK_LINE
local MOVEMENT_TRACK = default.MOVEMENT_TRACK
local movement_track_states = default.movement_track_states

local run_state = setmetatable({}, {__index = movement_track_states.run})

function run_state.entry(this, context)
    local state = this.movement_track_states.run
    state.mode = -1
    state.time = context:getCurrentTimestamp()
    context:runAnimation("run_start_override", context:getTrack(BLENDING_TRACK_LINE, MOVEMENT_TRACK), true, PLAY_ONCE_HOLD, 0.2)
end

function run_state.exit(this, context)
    context:runAnimation("run_end", context:getTrack(BLENDING_TRACK_LINE, MOVEMENT_TRACK), true, PLAY_ONCE_HOLD, 0.3)
end

function run_state.update(this, context)
    local track = context:getTrack(BLENDING_TRACK_LINE, MOVEMENT_TRACK)
    local state = this.movement_track_states.run

    if (context:isHolding(track)) then
        context:runAnimation("run_override", track, true, LOOP, 0.2)
        state.mode = 0
        context:anchorWalkDist()
    end

    if (state.mode ~= -1) then
        if (not context:isOnGround()) then
            if (state.mode ~= 1) then
                state.mode = 1
                context:runAnimation("run_hold_override", track, true, LOOP, 0.6)
            end
        else
            if (state.mode ~= 0) then
                state.mode = 0
                context:runAnimation("run_override", track, true, LOOP, 0.2)
            end
            context:setAnimationProgress(track, (context:getWalkDist() % 2.0) / 2.0, true)
        end
    end
end

local M = setmetatable({
    movement_track_states = setmetatable({
        run = run_state
    }, {__index = movement_track_states})
}, {__index = default})

return M
