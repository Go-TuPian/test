-- Disposable launchers select their put-away animation locally from the
-- outgoing gun stack. This avoids cross-side animation redirect timing.
local default = require("tacz_default_state_machine")

local STATIC_TRACK_LINE = default.STATIC_TRACK_LINE
local MAIN_TRACK = default.MAIN_TRACK
local main_track_states = default.main_track_states

-- Do not mutate the table returned by require. Only replace the idle state in
-- this derived state machine; every other default state remains inherited.
local idle_state = setmetatable({}, {__index = main_track_states.idle})

local function isSpent(context)
    return (not context:hasBulletInBarrel()) and (context:getAmmoCount() <= 0)
end

local function runPutAwayAnimation(context)
    local put_away_time = context:getPutAwayTime()
    local track = context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK)
    local animation = "put_away"

    if isSpent(context) and context:hasAnimationPrototype("put_away_empty") then
        animation = "put_away_empty"
    end

    context:runAnimation(animation, track, false, PLAY_ONCE_HOLD, put_away_time * 0.75)
    context:setAnimationProgress(track, 1, true)
    context:adjustAnimationProgress(track, -put_away_time, false)
end

function idle_state.transition(this, context, input)
    if (input == INPUT_PUT_AWAY) then
        runPutAwayAnimation(context)
        this.main_track_states.final.isfinal = 1
        return this.main_track_states.final
    end

    return main_track_states.idle.transition(this, context, input)
end

local M = setmetatable({
    main_track_states = setmetatable({
        idle = idle_state
    }, {__index = main_track_states})
}, {__index = default})

return M
