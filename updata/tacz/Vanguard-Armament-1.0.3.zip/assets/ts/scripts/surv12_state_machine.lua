-- 脚本的位置是 "{命名空间}:{路径}"，那么 require 的格式为 "{命名空间}_{路径}"
-- 注意！require 取得的内容不应该被修改，应仅调用
local default = require("tacz_default_state_machine")
local STATIC_TRACK_LINE = default.STATIC_TRACK_LINE
local MAIN_TRACK = default.MAIN_TRACK
local BOLT_CAUGHT_TRACK = default.BOLT_CAUGHT_TRACK
local main_track_states = default.main_track_states
-- main_track_states.idle 是我们要重写的状态。
local idle_state = setmetatable({}, {__index = main_track_states.idle})
local start_state = setmetatable({}, {__index = main_track_states.start})
local final_state = setmetatable({}, {__index = main_track_states.final})
local gun_kick_state = setmetatable({}, {__index = default.gun_kick_state})
-- reload_state、bolt_state 是定义的新状态，用于执行单发装填

function gun_kick_state.transition(this, context, input)
    if (input == INPUT_SHOOT) then
        local bandage = context:getAmmoCount()
        context:runAnimation("use_only_bandage_" .. bandage, context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK), false, PLAY_ONCE_STOP, 0)
    end
    return nil
end

function idle_state.transition(this, context, input)
    if (input == INPUT_PUT_AWAY) then
        local put_away_time = context:getPutAwayTime()
        -- 此处获取的轨道是位于主轨道行上的主轨道
        local track = context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK)
        -- 播放 put_away 动画,并且将其过渡时长设为从上下文里传入的 put_away_time * 0.75
        context:runAnimation("put_away", track, false, PLAY_ONCE_HOLD, put_away_time * 0.75)
        -- 设定动画进度为最后一帧
        context:setAnimationProgress(track, 1, true)
        -- 将动画进度向前拨动 {put_away_time}
        context:adjustAnimationProgress(track, -put_away_time, false)
        return this.main_track_states.final
    end
    if (input == INPUT_BAYONET_PUSH) then
        local health_state = context:getPlayerScoreInt("%Var_Surv12BandageCheck%")
        local bandage = context:getAmmoCount()
        if (health_state == 0) then
            context:runAnimation("use_no_bandage_" .. bandage, context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK), false, PLAY_ONCE_STOP, 0)
        else
            if (bandage ~= 0) then
                context:runAnimation("use_with_bandage_" .. bandage, context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK), false, PLAY_ONCE_STOP, 0)
            else
                context:runAnimation("use_no_bandage_0", context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK), false, PLAY_ONCE_STOP, 0)
            end
        end
        return this.main_track_states.idle
    end
end


-- 更新静止态
function idle_state.update(this, context)
    local track_2 = context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK)
    local isinterruptted = context:getPlayerScoreInt("%Var_Surv12UseInterrupter%")
    if (isinterruptted == 1) then
        context:runAnimation("static_idle", track_2, false, PLAY_ONCE_STOP, 0)
    end
    return this.main_track_states.idle
end

-- 用元表的方式继承默认状态机的属性
local M = setmetatable({
    main_track_states = setmetatable({
        idle = idle_state,
        start = start_state,
        final = final_state
    }, {__index = main_track_states}),
    gun_kick_state = gun_kick_state
}, {__index = default})
-- 先调用父级状态机的初始化函数，然后进行自己的初始化
function M:initialize(context)
    default.initialize(self, context)
end
-- 导出状态机
return M