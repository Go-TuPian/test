-- AK-50 only: independent ammo scrub track and server-authoritative bipod state.
local default = require("tacz_default_state_machine")
local function clone(value)
    if type(value) ~= "table" then return value end
    local copy = {}
    for k, v in pairs(value) do copy[k] = clone(v) end
    return copy
end
local M = clone(default)
local ammo_state, bipod_state = {}, {}
local BIPOD_OPEN_SECONDS = 2.0
local function ammoTrack(c) return c:getTrack(M.STATIC_TRACK_LINE, M.PARALLEL_TRACK_1) end
local function legTrack(c) return c:getTrack(M.BLENDING_TRACK_LINE, M.BLEND_TRACK_1) end
local function handTrack(c) return c:getTrack(M.BLENDING_TRACK_LINE, M.BLEND_TRACK_2) end
local function mainBusy(c) return not c:isStopped(c:getTrack(M.STATIC_TRACK_LINE, M.MAIN_TRACK)) end
local function removeTrack(c, track)
    -- stopAnimation does not clear pausing or an in-flight transition in TacZ.
    -- Remove the runner itself so a cancelled overlay cannot keep rendering.
    c:getStateMachine():getAnimationController():removeAnimation(track)
end
local function moving(c)
    return c:isInputUp() or c:isInputDown() or c:isInputLeft() or c:isInputRight()
        or c:isInputJumping() or not c:isOnGround()
end

function ammo_state.entry(self, c)
    self.ak50_reload = nil
    self.ak50_serial = c:getNbtAccessor():getInt("AK50ReloadSerial")
    c:runAnimation("static_drum_ammo", ammoTrack(c), false, LOOP, 0)
    c:pauseAnimation(ammoTrack(c))
    ammo_state.update(self, c)
end
function ammo_state.update(self, c)
    -- TacZ getAmmoCount excludes the separately stored chamber round.
    local count = math.max(0, math.min(20, c:getAmmoCount()))
    local nbt = c:getNbtAccessor()
    local serial = nbt:getInt("AK50ReloadSerial")
    local reload = self.ak50_reload
    if reload then
        local elapsed = (c:getCurrentTimestamp() - reload.started) / 1000
        if serial ~= reload.serial and nbt:getInt("AK50ReloadOldAmmo") == reload.old then
            local incoming = nbt:getInt("AK50ReloadPreview")
            if incoming >= 0 then reload.incoming = math.min(20, incoming) end
        end
        -- Author's replacement-round scale keyframe is 2.3125 s in both reloads.
        -- Keep the extracted magazine frozen; only the incoming magazine gets the forecast.
        if elapsed < 2.3125 then
            count = reload.old
        elseif elapsed < reload.feed then
            count = reload.incoming or reload.old
        elseif count == reload.old and reload.incoming and reload.incoming > reload.old then
            -- Do not flash the old/empty count while the feed update packet is in flight.
            count = reload.incoming
        end
        if elapsed > reload.finish or (elapsed > 0.1 and not mainBusy(c)) then
            self.ak50_reload = nil
            count = math.max(0, math.min(20, c:getAmmoCount()))
        end
    else
        self.ak50_serial = serial
    end
    -- Four rounds fit inside the opaque feed tower; 16 can be seen in the drum.
    -- Sample just after the pre/post discontinuity, as the stock M249 does.
    c:setAnimationProgress(ammoTrack(c), 20 - count + 0.05, false)
end

function ammo_state.transition(self, c, input)
    if input == INPUT_RELOAD then
        local empty = c:getAmmoCount() <= 0 and not c:hasBulletInBarrel()
        self.ak50_reload = {old = c:getAmmoCount(), serial = self.ak50_serial,
            started = c:getCurrentTimestamp(), feed = empty and 5.0 or 3.3,
            finish = empty and 6.17 or 4.8}
    elseif input == INPUT_PUT_AWAY or input == INPUT_SHOOT then
        self.ak50_reload = nil
    end
end

local function playLegs(c, name, hold, blend)
    c:runAnimation(name, legTrack(c), true, hold and PLAY_ONCE_HOLD or PLAY_ONCE_STOP, blend or 0.12)
end
function bipod_state.entry(self, c)
    self.ak50 = {phase = "off", hand = false, blocked = false, final = false}
end
function bipod_state.update(self, c)
    local s = self.ak50
    local requested = c:getPlayerScoreInt("%Var_AK50Bipod%")
    local epoch = c:getPlayerScoreInt("%Var_AK50Epoch%")
    -- A fresh server deployment can arrive without an intermediate zero snapshot.
    if requested == 0 or (s.epoch ~= nil and epoch ~= s.epoch) then s.blocked = false end
    s.epoch = epoch
    -- Do not reopen on a stale server snapshot after the client has started walking.
    if moving(c) or s.final then s.blocked = true end
    local wanted = requested > 0 and not s.blocked and not s.final
    local busy = mainBusy(c)
    if s.phase == "closing" and s.reverseFrom then
        local progress = math.max(0, s.reverseFrom -
            (c:getCurrentTimestamp() - s.closeStarted) / 1000)
        c:setAnimationProgress(legTrack(c), progress, false)
        if progress <= 0 then
            removeTrack(c, legTrack(c)); s.reverseFrom = nil; s.phase = "off"
        end
    end
    if not wanted and (s.phase == "opening" or s.phase == "deployed") then
        -- Pause the original opening and scrub backwards; no duplicated reverse
        -- keyframes. Zero transition binds pause/progress to the new runner itself.
        local reverseFrom = s.phase == "opening" and math.min(BIPOD_OPEN_SECONDS,
            math.max(0, (c:getCurrentTimestamp() - s.started) / 1000)) or nil
        local animation = reverseFrom and (busy and "ak50_hardware_open" or s.openAnimation) or
            ((busy or not s.hand) and "ak50_hardware_close" or "crawl_end")
        playLegs(c, animation, false, reverseFrom and 0 or 0.15)
        if reverseFrom then
            c:pauseAnimation(legTrack(c))
            c:setAnimationProgress(legTrack(c), reverseFrom, false)
        end
        removeTrack(c, handTrack(c)); s.hand = false; s.phase = "closing"
        s.closeStarted = c:getCurrentTimestamp()
        s.closeAnimation = animation
        s.reverseFrom = reverseFrom
    elseif wanted and s.phase == "off" then
        s.openAnimation = busy and "ak50_hardware_open" or "crawl_start"
        playLegs(c, s.openAnimation, true)
        s.started = c:getCurrentTimestamp()
        s.phase = "opening"
    end
    if s.phase == "opening" and (c:isHolding(legTrack(c)) or c:isStopped(legTrack(c))) then
        -- Keep the new opening's final hardware pose; do not switch to yesterday's
        -- separately-authored static placeholder. Opening ends at zero hand offset.
        s.phase = "deployed"
    elseif s.phase == "closing" and c:isStopped(legTrack(c)) then
        s.phase = "off"
    end
    if s.phase == "deployed" then
        -- Keep legs deployed during reload/inspect, but let the main hand animation win.
        if busy and s.hand then
            c:runAnimation("crawl_handdown", handTrack(c), true, PLAY_ONCE_HOLD, 0.1)
            s.hand = false
        elseif not busy and not s.hand then
            c:runAnimation("crawl_handup", handTrack(c), true, PLAY_ONCE_HOLD, 0.1)
            s.hand = true
        end
    end
end
function bipod_state.transition(self, c, input)
    if input == INPUT_PUT_AWAY then
        self.ak50.final = true
        self.ak50.reverseFrom = nil
        -- Hand control belongs entirely to put-away. Do not add a synthetic fast
        -- folding action over it or change the item's switching time.
        removeTrack(c, handTrack(c)); self.ak50.hand = false
        removeTrack(c, legTrack(c)); self.ak50.phase = "off"
    elseif input == INPUT_RELOAD or input == INPUT_INSPECT then
        if self.ak50.phase == "opening" then
            -- An interrupted hand action must not add its transform to reloading hands.
            -- A blended seek can target the OLD runner if it was paused.
            -- Bind the channel projection immediately before setting its progress.
            playLegs(c, "ak50_hardware_open", true, 0)
            self.ak50.openAnimation = "ak50_hardware_open"
            c:setAnimationProgress(legTrack(c), math.min(BIPOD_OPEN_SECONDS - 0.0001,
                math.max(0, (c:getCurrentTimestamp() - self.ak50.started) / 1000)), false)
        elseif self.ak50.phase == "closing" and self.ak50.reverseFrom then
            playLegs(c, "ak50_hardware_open", false, 0)
            c:pauseAnimation(legTrack(c))
            c:setAnimationProgress(legTrack(c), math.max(0, self.ak50.reverseFrom -
                (c:getCurrentTimestamp() - self.ak50.closeStarted) / 1000), false)
            self.ak50.closeAnimation = "ak50_hardware_open"
        elseif self.ak50.phase == "closing" and
            self.ak50.closeAnimation == "crawl_end" then
            -- Reload/inspect must not compete with the closing animation's hands/root.
            playLegs(c, "ak50_hardware_close", false, 0)
            c:setAnimationProgress(legTrack(c), math.min(2.2917,
                math.max(0, (c:getCurrentTimestamp() - self.ak50.closeStarted) / 1000)), false)
            self.ak50.closeAnimation = "ak50_hardware_close"
        end
    end
end

function M.gun_kick_state.transition(self, c, input)
    if input == INPUT_SHOOT then
        local deployed = c:getPlayerScoreInt("%Var_AK50Bipod%") == 2 and not moving(c)
        c:runAnimation(deployed and "shoot_bipod" or "shoot",
            c:findIdleTrack(self.GUN_KICK_TRACK_LINE, false), true, PLAY_ONCE_STOP, 0)
    end
end
function M:initialize(c)
    default.initialize(self, c)
    self.ak50 = nil
end
function M:states()
    local states = default.states(self)
    states[#states+1] = ammo_state
    states[#states+1] = bipod_state
    return states
end
function M:exit(c)
    removeTrack(c, ammoTrack(c)); removeTrack(c, legTrack(c)); removeTrack(c, handTrack(c))
end
return M
