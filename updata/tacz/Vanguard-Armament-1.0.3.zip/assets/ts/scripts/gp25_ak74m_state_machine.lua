-- AK74M + GP25 wrapper: retain Vanguard's complete underbarrel behavior and
-- only add attachment-ID-driven handguard visibility.
local base = require("ts_ak47_state_machine")
local STATIC_TRACK_LINE = base.STATIC_TRACK_LINE

-- Do not mutate the shared base module's stack pointer.  Reserve the first
-- index after its tracks only in this wrapper's context.
local HANDGUARD_TRACK = base.static_track_top.value
local EMPTY_ATTACHMENT = "tacz:empty"
local GP25_ATTACHMENT = "ts:weapon_gp25"

local handguard_state = {
    animation = nil,
    grip = nil,
    laser = nil
}

local function desiredAnimation(context)
    local grip = context:getAttachment("GRIP")
    local laser = context:getAttachment("LASER")

    -- GP25 alone keeps the original polymer handguard.  Any laser switches
    -- to the tactical handguard.  The fallback also hides the copied default
    -- bone if this composite model survives for a frame after GP25 removal.
    if grip == GP25_ATTACHMENT and laser == EMPTY_ATTACHMENT then
        return "handguard_gp25_default_state", grip, laser
    end
    return "handguard_laser_tactical_state", grip, laser
end

local function applyHandguardState(this, context)
    local animation, grip, laser = desiredAnimation(context)
    local track = context:getTrack(STATIC_TRACK_LINE, HANDGUARD_TRACK)
    if this.animation ~= animation
        or this.grip ~= grip
        or this.laser ~= laser
        or context:isStopped(track) then
        context:runAnimation(animation, track, false, LOOP, 0)
        this.animation = animation
        this.grip = grip
        this.laser = laser
    end
end

function handguard_state.entry(this, context)
    this.animation = nil
    this.grip = nil
    this.laser = nil
    applyHandguardState(this, context)
end

function handguard_state.update(this, context)
    applyHandguardState(this, context)
end

local M = setmetatable({
    handguard_state = handguard_state,
    HANDGUARD_TRACK = HANDGUARD_TRACK
}, {__index = base})

function M:initialize(context)
    base.initialize(self, context)
    context:ensureTracksAmount(STATIC_TRACK_LINE, HANDGUARD_TRACK + 1)
end

function M:states()
    local states = base.states(self)
    states[#states + 1] = self.handguard_state
    return states
end

return M
