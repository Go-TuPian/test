-- Shield-only presentation; native skinned RIGHT arm, no camera/Java interop.
local M = {}
local BASE, ACTION, AIM, MOTION = 0, 1, 2, 3
local idle, inspect, stowed = {}, {}, {}
local aim, motion, base = {}, {}, {}
local function play(context, name, track, blend, mode, fade)
    context:runAnimation(name, context:getTrack(0, track), blend, mode, fade)
end
local function stop(context, track)
    context:stopAnimation(context:getTrack(0, track))
end
local function action(this, context, input)
    if input == INPUT_PUT_AWAY then
        this.stowing = true
        -- Preserve the current ADS pose through exit instead of hard-stopping it.
        -- Fade the current locomotion offset to neutral on its own native track.
        play(context, "locomotion_idle", MOTION, true, LOOP, 0.18)
        play(context, "put_away", ACTION, true, PLAY_ONCE_HOLD, 0.1)
        return stowed
    elseif input == INPUT_BAYONET_PUSH or input == INPUT_BAYONET_STOCK or input == INPUT_BAYONET_MUZZLE then
        play(context, "melee_push", ACTION, true, PLAY_ONCE_STOP, 0.06)
        return idle
    elseif input == INPUT_DRAW then
        play(context, "draw", ACTION, true, PLAY_ONCE_STOP, 0)
        return idle
    end
end
function base.entry(this, context)
    play(context, "static_idle", BASE, false, LOOP, 0)
end
function idle.transition(this, context, input)
    local nextState = action(this, context, input)
    if nextState then return nextState end
    if input == INPUT_INSPECT and context:getAimingProgress() < 0.01 then return inspect end
end
function inspect.entry(this, context)
    play(context, "inspect", ACTION, true, PLAY_ONCE_STOP, 0.12)
end
function inspect.update(this, context)
    if context:getAimingProgress() > 0.01 or context:isStopped(context:getTrack(0, ACTION)) then
        context:trigger("eagle_iv:inspect_end")
    end
end
function inspect.transition(this, context, input)
    if input == "eagle_iv:inspect_end" then stop(context, ACTION) return idle end
    return action(this, context, input)
end
function aim.entry(this, context)
    play(context, "ads", AIM, true, PLAY_ONCE_HOLD, 0)
    context:pauseAnimation(context:getTrack(0, AIM))
end
function aim.update(this, context)
    if not this.stowing then context:setAnimationProgress(context:getTrack(0, AIM), context:getAimingProgress(), true) end
end
function motion.entry(this, context)
    this.motionName = "locomotion_idle"
    play(context, this.motionName, MOTION, true, LOOP, 0)
end
function motion.transition(this, context, input)
    if this.stowing then return end
    local name
    if input == INPUT_RUN then name = "run"
    elseif input == INPUT_WALK then name = "walk_forward"
    elseif input == INPUT_IDLE then name = "locomotion_idle" end
    if name and name ~= this.motionName then
        this.motionName = name
        play(context, name, MOTION, true, LOOP, 0.22)
    end
end
function M:initialize(context)
    context:ensureTrackLineSize(1)
    context:ensureTracksAmount(0, 4)
    -- Clear last use only when this display is initialized again, never at exit.
    for track = 0, 3 do stop(context, track) end
    self.stowing = false
    context:setShouldHideCrossHair(true)
end
function M:exit(context)
    -- Native tryExit triggers put_away then immediately calls this method.
    -- Its exiting window continues updating the controller after state exit.
    context:setShouldHideCrossHair(false)
end
function M:states() return {base, idle, aim, motion} end
return M
