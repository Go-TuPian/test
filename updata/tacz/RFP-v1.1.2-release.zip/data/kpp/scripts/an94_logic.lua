-- TacZ 1.1.8-hotfix / Forge 1.20.1.
-- AUTO: 0, 50, 150, 250, 350... ms; reset 250 ms after the last round.
-- Each shootOnce uses native ammo consumption and native burst scheduling.
local M = {}
local AUTO_MODE = 0
local BURST_INTERVAL_MS = 33       -- 1200 RPM, first -> second round
local NORMAL_INTERVAL_MS = 100     -- 600 RPM, second -> third and later
local RESET_MS = 250               -- measured from the last round
local CACHE_KEY = "an94_v1"

local function cacheFor(api)
    local c = api:getCachedScriptData()
    if type(c) ~= "table" or c.kind ~= CACHE_KEY then
        c = {kind = CACHE_KEY}
        api:cacheScriptData(c)
    end
    return c
end

function M.shoot(api)
    local c = cacheFor(api)
    if api:getFireMode() ~= AUTO_MODE then
        c.last_round_at, c.pair_until = nil, nil
        api:shootOnce(api:isShootingNeedConsumeAmmo())
        return
    end

    local now = api:getCurrentTimestamp()
    local pair = c.last_round_at == nil
        or now < c.last_round_at - BURST_INTERVAL_MS
        or now - c.last_round_at >= RESET_MS

    -- These overrides are queried synchronously by shootOnce. The native
    -- scheduler then fires the second round even if the trigger is released.
    c.emitting_pair = pair
    api:shootOnce(api:isShootingNeedConsumeAmmo())
    c.emitting_pair = false

    local next_trigger_interval = NORMAL_INTERVAL_MS
    if pair then
        c.last_round_at = now + BURST_INTERVAL_MS
        c.pair_until = c.last_round_at
        next_trigger_interval = BURST_INTERVAL_MS + NORMAL_INTERVAL_MS
    else
        c.last_round_at = now
        c.pair_until = nil
    end

    -- Server getShootInterval() already subtracts TacZ's 5 ms tolerance.
    -- Use the full native interval here, preserving that tolerance once.
    api:adjustShootInterval(next_trigger_interval - (api:getShootInterval() + 5))
end

function M.modify_property(api, id, original)
    local c = api:getCachedScriptData()
    if api:getFireMode() == AUTO_MODE and type(c) == "table"
        and c.kind == CACHE_KEY and c.emitting_pair then
        -- Supported by native shootOnce even in AUTO mode.
        if id == "burst_count" then return 2 end
        if id == "burst_shoot_interval" then return BURST_INTERVAL_MS end
    end
    return original
end

function M.start_reload(api)
    local c = cacheFor(api)
    -- Avoid beginning a reload in the middle of the committed 50 ms pair.
    if c.pair_until ~= nil and api:getCurrentTimestamp() <= c.pair_until then
        return false
    end
    c.last_round_at, c.pair_until = nil, nil
    return true
end

return M
